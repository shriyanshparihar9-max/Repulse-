package com.repulse.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface RepulseDao {
    @Query("SELECT * FROM habits WHERE isArchived = 0 ORDER BY orderIndex ASC")
    fun observeHabits(): Flow<List<HabitEntity>>

    @Query("SELECT * FROM habits")
    suspend fun getAllHabits(): List<HabitEntity>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertHabits(items: List<HabitEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertHabit(item: HabitEntity)

    @Query("SELECT * FROM daily_logs WHERE dateKey = :date")
    fun observeLogs(date: String): Flow<List<DailyLogEntity>>

    @Query("SELECT * FROM daily_logs")
    suspend fun getAllLogs(): List<DailyLogEntity>

    @Query("SELECT * FROM daily_logs WHERE dateKey = :date AND habitId = :habitId LIMIT 1")
    suspend fun getLog(date: String, habitId: String): DailyLogEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertLog(item: DailyLogEntity)

    @Query("SELECT * FROM active_timers WHERE habitId = :habitId LIMIT 1")
    suspend fun getTimer(habitId: String): ActiveTimerEntity?

    @Query("SELECT * FROM active_timers")
    fun observeTimers(): Flow<List<ActiveTimerEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTimer(item: ActiveTimerEntity)

    @Query("DELETE FROM active_timers WHERE habitId = :habitId")
    suspend fun deleteTimer(habitId: String)
}

@Database(
    entities = [HabitEntity::class, DailyLogEntity::class, ActiveTimerEntity::class],
    version = 1,
    exportSchema = false
)
abstract class RepulseDatabase : RoomDatabase() {
    abstract fun dao(): RepulseDao
}
