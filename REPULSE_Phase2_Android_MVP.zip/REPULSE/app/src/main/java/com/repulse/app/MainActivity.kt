package com.repulse.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Flame
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.room.Room
import com.repulse.app.data.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

private val Page = Color(0xFFF4F6F2)
private val Ink = Color(0xFF172019)
private val Muted = Color(0xFF707A70)
private val Lime = Color(0xFFB9F36D)
private val Green = Color(0xFF619D25)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = Room.databaseBuilder(applicationContext, RepulseDatabase::class.java, "repulse.db").build()
        val repo = RepulseRepository(db.dao())
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Green, onPrimary = Color.White,
                    background = Page, surface = Color.White,
                    onBackground = Ink, onSurface = Ink
                )
            ) {
                RepulseApp(repo)
            }
        }
    }
}

@Composable
private fun RepulseApp(repo: RepulseRepository) {
    val scope = rememberCoroutineScope()
    val today = LocalDate.now().toString()
    val habits by repo.habits().collectAsState(initial = emptyList())
    val logs by repo.logs(today).collectAsState(initial = emptyList())
    val timers by repo.timers().collectAsState(initial = emptyList())
    var streak by remember { mutableIntStateOf(0) }
    var best by remember { mutableIntStateOf(0) }
    var distanceInput by remember { mutableStateOf("") }
    var selectedTab by remember { mutableStateOf("Today") }

    LaunchedEffect(Unit) {
        repo.seedIfEmpty()
        streak = repo.currentStreak()
        best = repo.bestStreak()
    }
    LaunchedEffect(habits, logs) {
        streak = repo.currentStreak()
        best = repo.bestStreak()
    }

    // Refresh timer presentation frequently; timestamps remain the source of truth.
    var tick by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) { delay(250); tick = System.currentTimeMillis() }
    }

    Scaffold(
        containerColor = Page,
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                listOf("Today", "History", "Routines").forEach { tab ->
                    NavigationBarItem(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab },
                        icon = { Text(if (tab == "Today") "◷" else if (tab == "History") "▦" else "≡", fontSize = 20.sp) },
                        label = { Text(tab) }
                    )
                }
            }
        },
    ) { padding ->
        when (selectedTab) {
            "Today" -> TodayScreen(
                Modifier.padding(padding), habits, logs, timers, streak, tick,
                onIncrement = { h, n -> scope.launch { repo.addProgress(h, today, n) } },
                onToggle = { h, done -> scope.launch { repo.setDone(h, today, done) } },
                onStartTimer = { h -> scope.launch {
                    val old = repo.timer(h.id)
                    val now = System.currentTimeMillis()
                    val duration = h.targetValue.toLong() * 1000L
                    val elapsed = old?.accumulatedElapsedMillis ?: 0L
                    repo.updateTimer(h.id, ActiveTimerEntity(h.id, duration, now, elapsed, "RUNNING"))
                } },
                onPauseTimer = { h -> scope.launch {
                    val old = repo.timer(h.id) ?: return@launch
                    val elapsed = old.accumulatedElapsedMillis + (System.currentTimeMillis() - (old.startedAtEpochMillis ?: System.currentTimeMillis())).coerceAtLeast(0)
                    repo.updateTimer(h.id, old.copy(startedAtEpochMillis = null, accumulatedElapsedMillis = elapsed, status = "PAUSED"))
                } },
                onResumeTimer = { h -> scope.launch {
                    val old = repo.timer(h.id) ?: return@launch
                    repo.updateTimer(h.id, old.copy(startedAtEpochMillis = System.currentTimeMillis(), status = "RUNNING"))
                } },
                onResetTimer = { h -> scope.launch { repo.clearTimer(h.id) } },
                onTimerComplete = { h -> scope.launch {
                    repo.setDone(h, today, true)
                    repo.clearTimer(h.id)
                } },
                onDistance = { h, value -> scope.launch { repo.addProgress(h, today, value) } }
            )
            "History" -> SimpleHistory(Modifier.padding(padding), streak, best)
            else -> RoutinesScreen(Modifier.padding(padding), habits)
        }
    }

}

@Composable
private fun TodayScreen(
    modifier: Modifier,
    habits: List<HabitEntity>,
    logs: List<DailyLogEntity>,
    timers: List<ActiveTimerEntity>,
    streak: Int,
    tick: Long,
    onIncrement: (HabitEntity, Double) -> Unit,
    onToggle: (HabitEntity, Boolean) -> Unit,
    onStartTimer: (HabitEntity) -> Unit,
    onPauseTimer: (HabitEntity) -> Unit,
    onResumeTimer: (HabitEntity) -> Unit,
    onResetTimer: (HabitEntity) -> Unit,
    onTimerComplete: (HabitEntity) -> Unit,
    onDistance: (HabitEntity, Double) -> Unit
) {
    val logMap = logs.associateBy { it.habitId }
    val completed = habits.count { logMap[it.id]?.isCompleted == true }
    val progress = if (habits.isEmpty()) 0f else completed.toFloat() / habits.size
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            val date = LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale.getDefault()))
            Text("REPULSE", color = Green, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Spacer(Modifier.height(10.dp))
            Text("Make today count.", color = Ink, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text(date, color = Muted, fontSize = 14.sp)
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SummaryCard("Today's progress", "$completed/${habits.size}", "${(progress * 100).toInt()}% complete", Modifier.weight(1f))
                SummaryCard("Current streak", "$streak days", "Consistency adds up", Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().height(8.dp), color = Green, trackColor = Color(0xFFE3E9DF))
            Spacer(Modifier.height(12.dp))
            Text("TODAY'S ACTIVITIES", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
        }
        items(habits, key = { it.id }) { habit ->
            val log = logMap[habit.id]
            HabitCard(
                habit, log, timers.firstOrNull { it.habitId == habit.id }, tick,
                onIncrement, onToggle, onStartTimer, onPauseTimer, onResumeTimer,
                onResetTimer, onTimerComplete, onDistance
            )
        }
        if (habits.isEmpty()) item { Text("No activities yet. Add one to get started.", color = Muted) }
    }
}

@Composable
private fun SummaryCard(title: String, value: String, subtitle: String, modifier: Modifier = Modifier) {
    Surface(modifier, shape = RoundedCornerShape(20.dp), color = Color.White) {
        Column(Modifier.padding(16.dp)) {
            Text(title, color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            Text(value, color = Ink, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Green, fontSize = 11.sp)
        }
    }
}

@Composable
private fun HabitCard(
    habit: HabitEntity, log: DailyLogEntity?, timer: ActiveTimerEntity?, tick: Long,
    onIncrement: (HabitEntity, Double) -> Unit,
    onToggle: (HabitEntity, Boolean) -> Unit,
    onStartTimer: (HabitEntity) -> Unit,
    onPauseTimer: (HabitEntity) -> Unit,
    onResumeTimer: (HabitEntity) -> Unit,
    onResetTimer: (HabitEntity) -> Unit,
    onTimerComplete: (HabitEntity) -> Unit,
    onDistance: (HabitEntity, Double) -> Unit
) {
    val value = log?.currentValue ?: 0.0
    val done = log?.isCompleted == true
    val elapsed = remember(timer, tick) {
        if (timer == null) 0L else timer.accumulatedElapsedMillis +
            if (timer.status == "RUNNING") (tick - (timer.startedAtEpochMillis ?: tick)).coerceAtLeast(0) else 0L
    }
    val remaining = ((timer?.durationMillis ?: 0L) - elapsed).coerceAtLeast(0L)
    LaunchedEffect(timer?.status, remaining) {
        if (timer?.status == "RUNNING" && remaining <= 0L) onTimerComplete(habit)
    }
    var distanceText by remember { mutableStateOf("") }

    Surface(shape = RoundedCornerShape(20.dp), color = Color.White, shadowElevation = 1.dp) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(habit.title, color = Ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                    Text("${habit.type.lowercase().replaceFirstChar { it.uppercase() }} · Target ${habit.targetValue.toInt()} ${habit.unit}", color = Muted, fontSize = 12.sp)
                }
                if (done) {
                    Surface(color = Color(0xFFEAF8DE), shape = RoundedCornerShape(50)) {
                        Text("Done", color = Green, modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            if (habit.type == "TIMER") {
                Text(formatTime(remaining), color = Ink, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        when (timer?.status) {
                            "RUNNING" -> onPauseTimer(habit)
                            "PAUSED" -> onResumeTimer(habit)
                            else -> onStartTimer(habit)
                        }
                    }, modifier = Modifier.heightIn(min = 48.dp), colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Ink)) {
                        Icon(if (timer?.status == "RUNNING") Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = null)
                        Spacer(Modifier.width(4.dp))
                        Text(when (timer?.status) { "RUNNING" -> "Pause"; "PAUSED" -> "Resume"; else -> "Start" })
                    }
                    OutlinedButton(onClick = { onResetTimer(habit) }, modifier = Modifier.heightIn(min = 48.dp)) {
                        Icon(Icons.Default.Refresh, contentDescription = "Reset timer")
                        Text("Reset")
                    }
                }
                Text(if (timer?.status == "RUNNING") "In progress" else if (timer?.status == "PAUSED") "Paused" else "Ready", color = Muted, fontSize = 12.sp)
            } else if (habit.type == "CHECKBOX") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = done, onCheckedChange = { onToggle(habit, it) })
                    Text(if (done) "Completed — tap to undo" else "Mark as completed", color = Ink)
                }
            } else if (habit.type == "DISTANCE") {
                Text("${"%.1f".format(value)} / ${habit.targetValue} ${habit.unit}", color = Ink, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(value = distanceText, onValueChange = { distanceText = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("Add km") }, modifier = Modifier.weight(1f), singleLine = true)
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = {
                        val v = distanceText.toDoubleOrNull()
                        if (v != null && v > 0) { onDistance(habit, v); distanceText = "" }
                    }, modifier = Modifier.heightIn(min = 52.dp), colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Ink)) { Text("Add") }
                }
            } else {
                Text("${value.toInt()} / ${habit.targetValue.toInt()} ${habit.unit}", color = Ink, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                LinearProgressIndicator(progress = { (value / habit.targetValue).toFloat().coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().height(7.dp), color = Green, trackColor = Color(0xFFE7ECE3))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { onIncrement(habit, -1.0) }, modifier = Modifier.weight(1f).heightIn(min = 48.dp)) { Text("−1") }
                    Button(onClick = { onIncrement(habit, 1.0) }, modifier = Modifier.weight(1f).heightIn(min = 48.dp), colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Ink)) { Text("+1") }
                    Button(onClick = { onIncrement(habit, 5.0) }, modifier = Modifier.weight(1f).heightIn(min = 48.dp), colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Ink)) { Text("+5") }
                }
            }
        }
    }
}

@Composable
private fun SimpleHistory(modifier: Modifier, streak: Int, best: Int) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("History", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text("Your consistency at a glance", color = Muted)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SummaryCard("Current streak", "$streak days", "Consecutive qualifying days", Modifier.weight(1f))
            SummaryCard("Best streak", "$best days", "Personal record", Modifier.weight(1f))
        }
        Text("Your daily history calendar arrives in Phase 3.", color = Muted)
    }
}

@Composable
private fun RoutinesScreen(modifier: Modifier, habits: List<HabitEntity>) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Routines", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text("Your active activities", color = Muted)
        habits.forEach { h ->
            Surface(color = Color.White, shape = RoundedCornerShape(16.dp)) {
                Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(h.title, color = Ink, fontWeight = FontWeight.SemiBold)
                    Text("${h.targetValue} ${h.unit}", color = Muted)
                }
            }
        }
        Text("Custom habit creation, editing, reordering, and archive controls are planned for Phase 3.", color = Muted, fontSize = 12.sp)
    }
}

private fun formatTime(millis: Long): String {
    val seconds = (millis / 1000L).coerceAtLeast(0)
    return "%02d:%02d".format(seconds / 60, seconds % 60)
}
