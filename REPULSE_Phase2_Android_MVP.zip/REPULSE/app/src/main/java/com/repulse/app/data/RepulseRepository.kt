package com.repulse.app.data

import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate
import java.util.UUID

class RepulseRepository(private val dao: RepulseDao) {
    fun habits(): Flow<List<HabitEntity>> = dao.observeHabits()
    fun logs(date: String): Flow<List<DailyLogEntity>> = dao.observeLogs(date)
    fun timers(): Flow<List<ActiveTimerEntity>> = dao.observeTimers()

    suspend fun seedIfEmpty() {
        if (dao.getAllHabits().isEmpty()) {
            val now = System.currentTimeMillis()
            dao.insertHabits(listOf(
                HabitEntity("starter_pushups", "Push-ups", "COUNTER", 15.0, "reps", orderIndex = 0, createdAt = now),
                HabitEntity("starter_squats", "Squats", "COUNTER", 20.0, "reps", orderIndex = 1, createdAt = now),
                HabitEntity("starter_plank", "Plank", "TIMER", 30.0, "seconds", orderIndex = 2, createdAt = now),
                HabitEntity("starter_stretch", "Stretching", "CHECKBOX", 1.0, "done", orderIndex = 3, createdAt = now),
                HabitEntity("starter_walk", "Daily walk", "DISTANCE", 2.0, "km", orderIndex = 4, createdAt = now)
            ))
        }
    }

    suspend fun addProgress(habit: HabitEntity, date: String, amount: Double) {
        val old = dao.getLog(date, habit.id)
        val next = ((old?.currentValue ?: 0.0) + amount).coerceAtLeast(0.0)
        val complete = next >= habit.targetValue
        dao.upsertLog(DailyLogEntity(
            id = old?.id ?: UUID.randomUUID().toString(),
            dateKey = date,
            habitId = habit.id,
            currentValue = next,
            isCompleted = complete,
            completedAt = if (complete) old?.completedAt ?: System.currentTimeMillis() else null
        ))
    }

    suspend fun setDone(habit: HabitEntity, date: String, done: Boolean) {
        val old = dao.getLog(date, habit.id)
        dao.upsertLog(DailyLogEntity(
            id = old?.id ?: UUID.randomUUID().toString(),
            dateKey = date,
            habitId = habit.id,
            currentValue = if (done) habit.targetValue else 0.0,
            isCompleted = done,
            completedAt = if (done) System.currentTimeMillis() else null
        ))
    }

    suspend fun updateTimer(habitId: String, timer: ActiveTimerEntity) = dao.upsertTimer(timer)
    suspend fun timer(habitId: String) = dao.getTimer(habitId)
    suspend fun clearTimer(habitId: String) = dao.deleteTimer(habitId)

    suspend fun currentStreak(): Int {
        val habits = dao.getAllHabits().filter { !it.isArchived }
        if (habits.isEmpty()) return 0
        val logs = dao.getAllLogs().groupBy { it.dateKey }
        val today = LocalDate.now()
        fun qualifies(day: LocalDate): Boolean {
            val dayLogs = logs[day.toString()].orEmpty().associateBy { it.habitId }
            return habits.all { h -> dayLogs[h.id]?.isCompleted == true }
        }
        var cursor = if (qualifies(today)) today else today.minusDays(1)
        var streak = 0
        while (qualifies(cursor)) {
            streak++
            cursor = cursor.minusDays(1)
        }
        return streak
    }

    suspend fun bestStreak(): Int {
        val habits = dao.getAllHabits().filter { !it.isArchived }
        if (habits.isEmpty()) return 0
        val logs = dao.getAllLogs().groupBy { it.dateKey }
        val dates = logs.keys.mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }.sorted()
        var best = 0
        var run = 0
        var previous: LocalDate? = null
        for (date in dates) {
            val dayLogs = logs[date.toString()].orEmpty().associateBy { it.habitId }
            val qualifies = habits.all { dayLogs[it.id]?.isCompleted == true }
            if (!qualifies) { run = 0; previous = date; continue }
            run = if (previous != null && previous!!.plusDays(1) == date) run + 1 else 1
            best = maxOf(best, run)
            previous = date
        }
        return best
    }
}
