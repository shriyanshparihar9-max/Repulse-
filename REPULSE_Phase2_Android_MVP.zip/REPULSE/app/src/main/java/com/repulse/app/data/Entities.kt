package com.repulse.app.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "habits")
data class HabitEntity(
    @PrimaryKey val id: String,
    val title: String,
    val type: String,
    val targetValue: Double,
    val unit: String,
    val restSeconds: Int = 0,
    val orderIndex: Int = 0,
    val isArchived: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "daily_logs",
    indices = [Index(value = ["dateKey", "habitId"], unique = true), Index("dateKey"), Index("habitId")]
)
data class DailyLogEntity(
    @PrimaryKey val id: String,
    val dateKey: String,
    val habitId: String,
    val currentValue: Double = 0.0,
    val isCompleted: Boolean = false,
    val completedAt: Long? = null,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "active_timers")
data class ActiveTimerEntity(
    @PrimaryKey val habitId: String,
    val durationMillis: Long,
    val startedAtEpochMillis: Long?,
    val accumulatedElapsedMillis: Long,
    val status: String,
    val updatedAt: Long = System.currentTimeMillis()
)
